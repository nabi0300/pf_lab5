#include <iostream>
using namespace std;

int main (){
	int x, y;
	
	cout << "Enter First Number: ";
	cin >> x;
	
	cout << "Enter Second Number: ";
	cin >> y;
	
	if(x > y){
			cout << x << " is larger" << endl;

	}
	else if(x < y){
		cout << y << " is larger" << endl;
	}
	
	else{
		cout << "These Numbers are Equal";
	}
	
	return 0;
}
