#include <iostream>
using namespace std;

int main (){
	int x, y, sum, prod, diff;
	double quotient;
	
	cout << "Enter First Number: ";
	cin >> x;
	
	cout << "Enter Second Number: ";
	cin >> y;
	
	sum = x + y;
	prod = x * y;
	diff = x - y;
	quotient = x / y;
	
	cout << "Sum of Two Numbers is: " << sum << endl;
	cout << "Product of Two Numbers is: " << prod << endl;
	cout << "Difference of Two Numbers is: " << diff << endl;
	cout << "Quotient of Two Numbers is: " << quotient << endl;
	
	return 0;
}
