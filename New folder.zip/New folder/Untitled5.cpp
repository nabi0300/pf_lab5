#include <iostream>
using namespace std;

int main (){
	int x, y, sum, diff, prod;
	float division;
	char op;
	
	cout << "Enter First Numbers: ";
	cin >> x;
		cout << "Enter Second Numbers: ";
	cin >> y;
	
	cout << "Press '1' for addition" << endl;
	cout << "Press '2' for Difference" << endl;
	cout << "Press '3' for Product" << endl;
	cout << "Press '4' for Division" << endl;
	cin >> op;
	
	if (op == '1'){
		sum = x + y;
		cout << "Sum is: " << sum;
	}
	else if (op == '2'){
			diff = x - y;
		cout << "Difference is: " << diff;
	}
	else if (op == '3'){
			prod = x * y;
		cout << "Product is: " << prod;
	}
	else if (op == '4'){
			division = x / y;
		cout << "Division is: " << division;
	}
	else {
		cout << "Invalid Operator";
	}
	
	return 0;
}
