#include <iostream>
using namespace std;

int main (){
	int x, y, z, sum, prod;
	double avg;
	
	cout << "Enter First Number: ";
	cin >> x;
	
	cout << "Enter Second Number: ";
	cin >> y;
	
	cout << "Enter Third Number: ";
	cin >> z;
	
	sum = x + y + z;
	prod = x * y * z;
	avg = (x + y + z) / 3;
	cout << "Sum of three Numbers is: " << sum << endl;
	cout << "Product of three Numbers is: " << prod << endl;
	cout << "Average of three Numbers is: " << avg << endl;
	if (x > y && x > z){
		cout << "Largest is: " << x << endl;
	}
	else if(y > x && y > z) {
		cout << "Largest is: " << y << endl;
	}
	else{
		cout << "Largest is: " << z << endl;
	}
	if (x < y && x < z){
		cout << "Smallest is: " << x << endl;
	}
	else if(y < x && y < z) {
		cout << "Smallest is: " << y << endl;
	}
	else{
		cout << "Smallest is: " << z << endl;
	}
	
	return 0;
}
